<?php

$conf = [
    'client_id': '',
    'client_secret': '',
    'redirect_uri': '',
    'scope': '',
    'authorize_uri': 'http://192.168.0.21:10000/authorize',
    'token_uri': 'http://192.168.0.21:10000/token',
    'user_uri': 'http://192.168.0.21:10000/user/info'
];

/**
 * @param array $params
 * @return string
 */
public function loginUri()
{
    $params = [];
    $appid = isset($conf['client_id']) ? $conf['client_id'] : '';
    $redirect_uri = isset($conf['redirect_uri']) ? $conf['redirect_uri'] : '';
    $server_uri = isset($conf['authorize_uri']) ? $conf['authorize_uri'] : '';
    if ($server_uri && $redirect_uri) {
        $params['redirect_uri'] = $redirect_uri;
        $params['response_type'] = 'code';
        if ($appid && $appid_key) {
            $params[$appid_key] = $appid;
        }
        $uri = new Purl\Url($server_uri);
        $uri->query->setData($params);
        return $uri->getUrl();
    }
    return '';
}

/**
 * @param string $code
 * @return string|null
 */
public static function getAccessToken($code)
{
    $params = [];
    $server_uri = $conf['token_uri'];
    $appid = isset($conf['client_id']) ? $conf['client_id'] : '';
    $appsec = isset($conf['client_secret']) ? $conf['client_secret'] : '';
    $redirect_uri = isset($conf['redirect_uri']) ? $conf['redirect_uri'] : '';
    if ($server_uri && $redirect_uri && $code) {
        $params['redirect_uri'] = $redirect_uri;
        $params['grant_type'] = 'authorization_code';
        $params['code'] = $code;
        //app id and secret
        if ($appid && $appsec) {
            $params['client_id'] = $appid;
            $params['client_secret'] = $appsec;
        }
        $uri = new Purl\Url($server_uri);
        $uri->query->setData($params);
        $client = new GuzzleHttp\Client();
        $res = $client->get($uri->getUrl());
        if ($res) {
            $json = json_decode($res->getBody(), true);
            return $json;
        }
    }
    return null;
}

/**
 * @param string $token
 * @return array
 */
private static function getUser($token)
{
    $uri = $conf['user_uri'];
    $res = self::getResource($uri, $token);
    return $res;
}

/**
 * @param $api_uri
 * @param $token
 * @param array $params
 * @return array
 */
private static function getResource($api_uri, $token, $params = [])
{
    $appid = isset($conf['client_id']) ? $conf['client_id'] : '';
    if ($appid) {
        $params['app_key'] = $appid;
    }
    $params['access_token'] = $token;
    $uri = new Purl\Url($api_uri);
    $uri->query->setData($params);
    $client = new GuzzleHttp\Client();
    $res = $client->get($uri->getUrl());
    return json_decode($res->getBody(), true);
}
