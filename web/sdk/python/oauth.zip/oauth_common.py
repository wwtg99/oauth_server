# -*- coding:utf-8 -*-
__author__ = 'wuwentao'

import requests

conf = {
    'client_id': '',
    'client_secret': '',
    'redirect_uri': 'localhost',  # redirect uri after authorization to get code
    'scope': '',  # the scopes needed, commas separated
    'authorize_uri': 'http://192.168.0.21:10000/authorize',  # the uri to authorize
    'token_uri': 'http://192.168.0.21:10000/token',  # the uri to get access token
    'user_uri': 'http://192.168.0.21:10000/user/info'  # thr uri to get user info
}


def login_uri():
    """
    Get login URI.
    :return: login URI
    :rtype: str
    """
    data = {'redirect_uri': conf['redirect_uri'], 'response_type': 'code'}
    if 'client_id' in conf and len(conf['client_id']) > 0:
        data['client_id'] = conf['client_id']
    if 'scope' in conf and len(conf['scope']) > 0:
        data['scope'] = conf['scope']
    uri = format_uri(conf['authorize_uri'], data)
    return uri


def get_access_token(code):
    """
    Get access_token with code.
    :param str code:
    :return: access_token and expires_in
    :rtype: dict
    """
    data = {'grant_type': 'authorization_code', 'redirect_uri': conf['redirect_uri'], 'code': code}
    if 'client_id' in conf and len(conf['client_id']) > 0 and 'client_secret' in conf and len(conf['client_secret']) > 0:
        data['client_id'] = conf['client_id']
        data['client_secret'] = conf['client_secret']
    uri = format_uri(conf['token_uri'], data)
    r = requests.get(uri)
    return r.json()


def get_user(token):
    """
    Get user info.
    :param str token:
    :return: user info
    :rtype: dict
    """
    uri = conf['user_uri']
    return get_resource(uri, token)


def get_resource(uri, token, params={}):
    """
    Get resource with access_token
    :param str uri:
    :param str token:
    :param dict params: Other params to send
    :return: retrieved data
    :rtype: dict
    """
    params['access_token'] = token
    if 'client_id' in conf and len(conf['client_id']) > 0:
        params['app_key'] = conf['client_id']
    u = format_uri(uri, params)
    r = requests.get(u)
    return r.json()


def format_uri(uri, data):
    """
    :param str uri:
    :param dict data:
    :return: formatted uri
    :rtype: str
    """
    p = []
    u = uri
    for k in data:
        p.append(k + '=' + data[k])
    if len(p) > 0:
        u += '?' + '&'.join(p)
    return u
